﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace it2a_spol_blind_map
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<MapPoint> points = new List<MapPoint>()
        {
            new MapPoint(){Name="Praha", XPercent=0.3718, YPercent=0.3770},
            new MapPoint(){Name="Brno", XPercent=0.6900, YPercent=0.7200},
            new MapPoint(){Name="Ostrava", XPercent=0.9458, YPercent=0.4696}

        };

        // Hra
        private readonly List<string> cities = new List<string>() { "Praha", "Brno", "Ostrava" };
        private readonly Random rnd = new Random();
        private string currentTarget = null!;
        private int score = 0;

        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Loaded;
        }

        void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            DrawPoints();
            UpdateScoreText();
            PickNewTarget();
        }

        private void MapImage_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            DrawPoints();
        }

        void DrawPoints()
        {
            OverlayCanvas.Children.Clear();

            foreach (var point in points)
            {
                double x = MapImage.ActualWidth * point.XPercent;
                double y = MapImage.ActualHeight * point.YPercent;

                Button btn = new Button()
                {
                    Content = point.Name,
                    Tag = point
                };

                btn.Click += Btn_Click;

                Canvas.SetLeft(btn, x);
                Canvas.SetTop(btn, y);

                OverlayCanvas.Children.Add(btn);
            }
        }

        // Klik z dynamicky vykreslených bodů (MapPoint)
        private void Btn_Click(object? sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is MapPoint point)
            {
                CheckGuess(point.Name);
            }
        }

        // Klik ze statických tlačítek v XAML
        //private void CityButton_Click(object sender, RoutedEventArgs e)
        //{
        //    if (sender is Button btn && btn.Content is string name)
        //    {
        //        CheckGuess(name);
        //    }
        //}

        private void CheckGuess(string guessedName)
        {
            bool correct = string.Equals(guessedName, currentTarget, StringComparison.OrdinalIgnoreCase);

            if (correct)
            {
                score++;
                UpdateScoreText();
                MessageBox.Show($"Správně — {guessedName}! Skóre +1.", "Výsledek", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show($"Špatně — vybral(a) jste {guessedName}. Správně bylo {currentTarget}.", "Výsledek", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

            PickNewTarget();
        }

        private void PickNewTarget()
        {
            if (cities.Count == 0)
            {
                currentTarget = string.Empty;
                TargetCityTextBlock.Text = "Najdi: —";
                return;
            }

            // Náhodně vybereme další cílové město
            int idx = rnd.Next(cities.Count);
            currentTarget = cities[idx];
            TargetCityTextBlock.Text = "Najdi: " + currentTarget;
        }

        private void UpdateScoreText()
        {
            ScoreTextBlock.Text = "Skóre: " + score;
        }

        //private void MapImage_MouseDown(object sender, MouseButtonEventArgs e)
        //{
        //    var pos = e.GetPosition(MapImage);

        //    double xPercent = pos.X / MapImage.ActualWidth;
        //    double yPercent = pos.Y / MapImage.ActualHeight;

        //    MessageBox.Show($"{xPercent:F4} , {yPercent:F4}");
        //}
    }
}